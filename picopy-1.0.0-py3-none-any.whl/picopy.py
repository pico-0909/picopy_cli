﻿from __future__ import annotations

__version__ = "1.0.0"

"""
picopy — a tiny, portable, zero-dependency CLI framework.

کاربر فقط با چند خط، CLI حرفه‌ای می‌سازه.
"""

import os
import sys
import re
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

# ═════════════════════════════════════════════════════════════════════
# BOOTSTRAP
# ═════════════════════════════════════════════════════════════════════
_LIBS_DIR = (Path(__file__).resolve().parent / "libs").resolve()
if _LIBS_DIR.is_dir() and str(_LIBS_DIR) not in sys.path:
    sys.path.insert(0, str(_LIBS_DIR))

try:
    import questionary
    from questionary import Style
    _HAS_Q = True
except ImportError:
    questionary = None
    Style = None
    _HAS_Q = False


# ═════════════════════════════════════════════════════════════════════
# COLORS
# ═════════════════════════════════════════════════════════════════════
_ESC = "\033["
_RESET = f"{_ESC}0m"

_COLORS = {
    "black": "30", "red": "31", "green": "32", "yellow": "33",
    "blue": "34", "magenta": "35", "cyan": "36", "white": "37",
    "bright_black": "90", "bright_red": "91", "bright_green": "92",
    "bright_yellow": "93", "bright_blue": "94", "bright_magenta": "95",
    "bright_cyan": "96", "bright_white": "97",
    "gray": "90", "grey": "90", "orange": "38;5;208",
    "pink": "38;5;205", "purple": "38;5;93", "teal": "38;5;30",
    "lime": "38;5;118", "gold": "38;5;220", "silver": "38;5;250",
    "navy": "38;5;17", "maroon": "38;5;88", "aqua": "38;5;51",
    "violet": "38;5;99", "coral": "38;5;209", "mint": "38;5;121",
    "peach": "38;5;216", "crimson": "38;5;161", "emerald": "38;5;35",
    "amber": "38;5;214", "lavender": "38;5;183",
}


def _fg(color):
    if not color:
        return None
    c = color.strip().lower()
    if c in _COLORS:
        return _COLORS[c]
    if c.startswith("#") and len(c) == 7:
        try:
            r = int(c[1:3], 16); g = int(c[3:5], 16); b = int(c[5:7], 16)
            return f"38;2;{r};{g};{b}"
        except ValueError:
            return None
    return None


def paint(text, color=None, bold=False, italic=False, underline=False,
          dim=False, color_enabled=True):
    if not color_enabled or not text:
        return text
    codes = []
    fg = _fg(color) if color else None
    if fg: codes.append(fg)
    if bold: codes.append("1")
    if dim: codes.append("2")
    if italic: codes.append("3")
    if underline: codes.append("4")
    if not codes:
        return text
    return f"{_ESC}{';'.join(codes)}m{text}{_RESET}"


_ANSI_RE = re.compile(r"\033\[[0-9;]*m")


def strip_ansi(text):
    return _ANSI_RE.sub("", text)


def visible_len(text):
    return len(strip_ansi(text))


def markup(text, color_enabled=True):
    if not color_enabled or "[" not in text:
        return text
    pattern = re.compile(r"\[([a-zA-Z#0-9_; ]+)\](.*?)\[/\1\]", re.DOTALL)

    def repl(m):
        spec, inner = m.group(1), m.group(2)
        color = None
        kw = {}
        for t in spec.replace(",", " ").split():
            tl = t.lower()
            if tl == "bold": kw["bold"] = True
            elif tl == "italic": kw["italic"] = True
            elif tl == "underline": kw["underline"] = True
            elif tl == "dim": kw["dim"] = True
            else: color = tl
        return paint(markup(inner, color_enabled), color, color_enabled=color_enabled, **kw)

    prev = None
    out = text
    while prev != out:
        prev = out
        out = pattern.sub(repl, out)
    return out


# ═════════════════════════════════════════════════════════════════════
# THEMES
# ═════════════════════════════════════════════════════════════════════
THEMES = {
    "dark": {
        "primary": "cyan", "success": "green", "error": "red",
        "warning": "yellow", "info": "blue", "muted": "gray",
        "text": "white", "title": "cyan", "border": "bright_black",
    },
    "dracula": {
        "primary": "magenta", "success": "green", "error": "red",
        "warning": "yellow", "info": "cyan", "muted": "gray",
        "text": "white", "title": "magenta", "border": "purple",
    },
    "nord": {
        "primary": "cyan", "success": "green", "error": "red",
        "warning": "yellow", "info": "blue", "muted": "gray",
        "text": "white", "title": "cyan", "border": "blue",
    },
    "gruvbox": {
        "primary": "yellow", "success": "green", "error": "red",
        "warning": "orange", "info": "blue", "muted": "gray",
        "text": "white", "title": "yellow", "border": "orange",
    },
    "light": {
        "primary": "blue", "success": "green", "error": "red",
        "warning": "yellow", "info": "blue", "muted": "gray",
        "text": "black", "title": "blue", "border": "gray",
    },
    "mono": {
        "primary": "white", "success": "white", "error": "white",
        "warning": "white", "info": "white", "muted": "white",
        "text": "white", "title": "white", "border": "white",
    },
}


def _qstyle(theme):
    if not _HAS_Q:
        return None
    p = theme["primary"]
    return Style([
        ("qmark",       f"fg:{p} bold"),
        ("question",    f"fg:{theme['text']} bold"),
        ("answer",      f"fg:{theme['success']} bold"),
        ("pointer",     f"fg:{p} bold"),
        ("highlighted", f"fg:{p} bold"),
        ("selected",    f"fg:{theme['success']}"),
        ("separator",   f"fg:{theme['muted']}"),
        ("instruction", f"fg:{theme['muted']} italic"),
    ])


# ═════════════════════════════════════════════════════════════════════
# TERMINAL
# ═════════════════════════════════════════════════════════════════════
class Terminal:
    @staticmethod
    def clear():
        os.system("cls" if os.name == "nt" else "clear")

    @staticmethod
    def size():
        try:
            sz = os.get_terminal_size()
            return sz.columns, sz.lines
        except Exception:
            return 80, 24

    @staticmethod
    def supports_color():
        if os.environ.get("NO_COLOR"):
            return False
        return sys.stdout.isatty()


# ═════════════════════════════════════════════════════════════════════
# SPINNER
# ═════════════════════════════════════════════════════════════════════
class Spinner:
    FRAMES = ["|", "/", "-", "\\"]

    def __init__(self, text="Loading...", color="cyan", color_enabled=True):
        self.text = text
        self.color = color
        self.color_enabled = color_enabled
        self._stop = threading.Event()
        self._thread = None

    def _spin(self):
        i = 0
        while not self._stop.is_set():
            frame = self.FRAMES[i % len(self.FRAMES)]
            msg = paint(f"{frame} {self.text}", self.color,
                        color_enabled=self.color_enabled)
            sys.stdout.write("\r" + msg + "   ")
            sys.stdout.flush()
            i += 1
            time.sleep(0.1)
        sys.stdout.write("\r" + " " * (len(self.text) + 15) + "\r")
        sys.stdout.flush()

    def __enter__(self):
        self._thread = threading.Thread(target=self._spin, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *a):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=0.5)


# ═════════════════════════════════════════════════════════════════════
# PROGRESS BAR
# ═════════════════════════════════════════════════════════════════════
class Progress:
    def __init__(self, total=100, width=40, color="cyan",
                 color_enabled=True, prefix=""):
        self.total = total
        self.width = width
        self.color = color
        self.color_enabled = color_enabled
        self.prefix = prefix
        self.current = 0

    def update(self, n=1):
        self.current += n
        self.draw()

    def draw(self):
        pct = min(1.0, self.current / self.total) if self.total else 0
        filled = int(self.width * pct)
        bar = "#" * filled + "-" * (self.width - filled)
        line = f"{self.prefix}[{bar}] {int(pct*100)}%"
        colored = paint(line, self.color, color_enabled=self.color_enabled)
        sys.stdout.write("\r" + colored)
        sys.stdout.flush()

    def done(self):
        self.current = self.total
        self.draw()
        print()

    def __enter__(self):
        self.draw()
        return self

    def __exit__(self, *a):
        if self.current < self.total:
            self.done()


# ═════════════════════════════════════════════════════════════════════
# MENU
# ═════════════════════════════════════════════════════════════════════
@dataclass
class _Entry:
    label: str
    target: Any = None
    icon: str = ""
    color: Optional[str] = None
    kind: str = "item"


class Menu:
    def __init__(self, name, title=None, icon="", color=None):
        self.name = name
        self.title = title or name
        self.icon = icon
        self.color = color
        self.entries: List[_Entry] = []

    def go(self, label, target, icon="", color=None):
        self.entries.append(_Entry(label, target, icon, color, "item"))
        return self

    def do(self, label, fn, icon="", color=None):
        return self.go(label, fn, icon, color)

    def line(self):
        self.entries.append(_Entry("", kind="sep"))
        return self

    def back(self, label=None):
        self.entries.append(_Entry(label or "<- Back", "_BACK_", kind="back"))
        return self

    def quit(self, label="Exit", message=None):
        self.entries.append(_Entry(label, message or "Bye!", kind="quit"))
        return self

    def color_of(self, c):
        self.color = c
        return self

    def title_of(self, t):
        self.title = t
        return self


# ═════════════════════════════════════════════════════════════════════
# FORM
# ═════════════════════════════════════════════════════════════════════
@dataclass
class _Field:
    kind: str
    key: str
    label: str
    default: Any = None
    choices: Optional[List[str]] = None
    validate: Optional[Callable] = None
    color: Optional[str] = None
    icon: str = ""
    placeholder: str = ""
    min: Optional[int] = None
    max: Optional[int] = None


class Form:
    def __init__(self, name, title=None, icon="", color=None):
        self.name = name
        self.title = title or name
        self.icon = icon
        self.color = color
        self.fields: List[_Field] = []
        self.texts: List[Tuple[str, Optional[str]]] = []
        self.on_save = None
        self.on_cancel = None
        self.on_load = None

    def text(self, label, key=None, default="", placeholder="",
             validate=None, color=None, icon=""):
        self.fields.append(_Field("text", key or _slug(label), label,
                                  default, None, validate, color, icon,
                                  placeholder))
        return self

    def password(self, label, key=None, validate=None, color=None, icon=""):
        self.fields.append(_Field("password", key or _slug(label), label,
                                  None, None, validate, color, icon))
        return self

    def yes_no(self, label, key=None, default=False, color=None, icon=""):
        self.fields.append(_Field("confirm", key or _slug(label), label,
                                  default, None, None, color, icon))
        return self

    def choose(self, label, choices, key=None, default=None,
               color=None, icon=""):
        self.fields.append(_Field("select", key or _slug(label), label,
                                  default, choices, None, color, icon))
        return self

    def many(self, label, choices, key=None, color=None, icon=""):
        self.fields.append(_Field("multi", key or _slug(label), label,
                                  None, choices, None, color, icon))
        return self

    def number(self, label, key=None, default=0, min=None, max=None,
               color=None, icon=""):
        f = _Field("number", key or _slug(label), label, default,
                   None, None, color, icon)
        f.min, f.max = min, max
        self.fields.append(f)
        return self

    def path(self, label, key=None, default="", must_exist=False,
             color=None, icon=""):
        f = _Field("path", key or _slug(label), label, default,
                   None, None, color, icon)
        f.placeholder = "exists" if must_exist else ""
        self.fields.append(f)
        return self

    def info(self, text, color=None):
        self.texts.append((text, color))
        return self

    def save(self, fn):
        self.on_save = fn
        return fn

    def cancel(self, fn):
        self.on_cancel = fn
        return fn

    def load(self, fn):
        self.on_load = fn
        return fn

    def color_of(self, c):
        self.color = c
        return self


def _slug(s):
    return re.sub(r"[^a-z0-9_]+", "_", s.lower()).strip("_")


# ═════════════════════════════════════════════════════════════════════
# APP
# ═════════════════════════════════════════════════════════════════════
class App:
    def __init__(self, title="App", version="", theme="dark", width=60):
        self.title = title
        self.version = version
        self.theme = dict(THEMES.get(theme, THEMES["dark"]))
        self.width = width
        self.color_enabled = Terminal.supports_color()

        self._registry: Dict[str, Any] = {}
        self._first: Optional[str] = None

        self.running = True
        self.screen = None
        self.current = None
        self.history: List[str] = []

    def menu(self, name, title=None, icon="", color=None):
        def deco(fn):
            m = Menu(name, title, icon, color)
            fn(m)
            self._registry[name] = m
            if self._first is None:
                self._first = name
            return fn
        return deco

    def form(self, name, title=None, icon="", color=None):
        def deco(fn):
            f = Form(name, title, icon, color)
            fn(f)
            self._registry[name] = f
            return fn
        return deco

    def goto(self, name):
        obj = self._registry.get(name)
        if obj is None:
            self.error(f"Unknown: {name}")
            return
        self.history.append(name)
        self.current = obj
        self.screen = "menu" if isinstance(obj, Menu) else "form"

    def go_back(self):
        if len(self.history) > 1:
            self.history.pop()
            name = self.history[-1]
            obj = self._registry.get(name)
            if obj:
                self.current = obj
                self.screen = "menu" if isinstance(obj, Menu) else "form"
                return
        if self._first:
            self.history = [self._first]
            self.goto(self._first)

    def clear(self):
        Terminal.clear()

    def header(self, title, icon=""):
        c = self.theme["title"]
        line = "=" * self.width
        print(paint(line, c, color_enabled=self.color_enabled))
        label = f"{icon}  {title}" if icon else title
        print(paint(f"  {label}", c, True, color_enabled=self.color_enabled))
        if self.version:
            print(paint(f"  v{self.version}", self.theme["muted"],
                        color_enabled=self.color_enabled))
        print(paint(line, c, color_enabled=self.color_enabled))
        print()

    def rule(self):
        print(paint("-" * self.width, self.theme["muted"],
                    color_enabled=self.color_enabled))

    def print(self, text="", color=None, bold=False):
        t = markup(text, self.color_enabled)
        if color or bold:
            t = paint(t, color, bold, color_enabled=self.color_enabled)
        print(t)

    def ok(self, msg): self.print(f"[OK] {msg}", self.theme["success"])
    def error(self, msg): self.print(f"[X] {msg}", self.theme["error"])
    def warn(self, msg): self.print(f"[!] {msg}", self.theme["warning"])
    def info(self, msg): self.print(f"[i] {msg}", self.theme["info"])
    def title(self, msg): self.print(msg, self.theme["title"], True)

    def pause(self, msg="Press Enter..."):
        try:
            input(paint(msg, self.theme["muted"],
                        color_enabled=self.color_enabled))
        except (EOFError, KeyboardInterrupt):
            pass

    def spinner(self, text="Loading..."):
        return Spinner(text, self.theme["primary"], self.color_enabled)

    def progress(self, total=100, prefix=""):
        return Progress(total, color=self.theme["primary"],
                        color_enabled=self.color_enabled, prefix=prefix)

    def ask(self, question, default=""):
        if not _HAS_Q:
            return input(question + " ")
        return questionary.text(question, default=default,
                                style=_qstyle(self.theme)).ask()

    def confirm(self, question, default=False):
        if not _HAS_Q:
            r = input(question + " [y/N] ").strip().lower()
            return r in ("y", "yes")
        return questionary.confirm(question, default=default,
                                   style=_qstyle(self.theme)).ask()

    def pick(self, question, choices):
        if not _HAS_Q:
            for i, c in enumerate(choices, 1):
                print(f"  {i}) {c}")
            r = input("Choose: ").strip()
            return choices[int(r)-1] if r.isdigit() else None
        return questionary.select(question, choices=choices,
                                  style=_qstyle(self.theme)).ask()

    def run(self):
        if not self._first:
            self.error("No menu registered.")
            return

        self.goto(self._first)

        while self.running:
            self.clear()
            if self.screen == "menu":
                self._run_menu()
            elif self.screen == "form":
                self._run_form()

        self.clear()
        self.ok("Goodbye!")

    # ─── منو ───
    def _run_menu(self):
        menu = self.current
        self.header(menu.title, menu.icon)

        selectable = []
        for e in menu.entries:
            if e.kind == "sep":
                self.rule()
                continue
            selectable.append((e, f"{e.icon}  {e.label}" if e.icon else e.label))

        if not selectable:
            self.pause()
            self.running = False
            return

        if not _HAS_Q:
            return self._fallback_menu(selectable)

        # 🔑 بدون رنگ توی choices — رنگ‌ها از style میان
        plain_choices = [label for _, label in selectable]
        label_map = {label: e for e, label in selectable}

        try:
            ans = questionary.select("Choose:", choices=plain_choices,
                                     style=_qstyle(self.theme),
                                     qmark=">").ask()
        except KeyboardInterrupt:
            self.running = False
            return

        if ans is None:
            self.running = False
            return

        entry = label_map.get(ans)
        if entry is None:
            return

        if entry.kind == "quit":
            if entry.target:
                self.print(markup(str(entry.target),
                                  color_enabled=self.color_enabled))
            self.running = False
            return

        if entry.kind == "back":
            self.go_back()
            return

        target = entry.target
        if target is None:
            return

        if isinstance(target, str):
            self.goto(target)
        else:
            try:
                result = target()
            except KeyboardInterrupt:
                self.running = False
                return
            if result is False:
                self.go_back()

    def _fallback_menu(self, selectable):
        for i, (_, label) in enumerate(selectable, 1):
            print(f"  {i}) {label}")
        raw = input("Choose: ").strip()
        if not raw.isdigit():
            return
        i = int(raw) - 1
        if not (0 <= i < len(selectable)):
            return
        entry = selectable[i][0]
        if entry.kind == "quit":
            self.running = False
        elif entry.kind == "back":
            self.go_back()
        elif isinstance(entry.target, str):
            self.goto(entry.target)
        elif callable(entry.target):
            entry.target()

    # ─── فرم ───
    def _run_form(self):
        form = self.current
        self.header(form.title, form.icon)

        for text, color in form.texts:
            self.print(text, color)
        if form.texts:
            print()

        if not _HAS_Q:
            self.error("questionary not available.")
            self.go_back()
            return

        values = {}
        for f in form.fields:
            try:
                ans = self._ask_field(f)
            except KeyboardInterrupt:
                if form.on_cancel:
                    form.on_cancel()
                self.go_back()
                return
            if ans is None:
                if form.on_cancel:
                    form.on_cancel()
                self.go_back()
                return
            values[f.key] = ans

        try:
            pick = questionary.select("Action:",
                                      choices=["Save", "<- Back"],
                                      style=_qstyle(self.theme),
                                      qmark=">").ask()
        except KeyboardInterrupt:
            self.go_back()
            return

        if pick == "Save" and form.on_save:
            form.on_save(values)
        elif pick == "<- Back" and form.on_cancel:
            form.on_cancel()

        self.go_back()

    def _ask_field(self, f: _Field):
        style = _qstyle(self.theme)
        label = f"{f.icon} {f.label}".strip() if f.icon else f.label

        if f.kind == "text":
            return questionary.text(label, default=str(f.default or ""),
                                    style=style,
                                    validate=f.validate or (lambda _: True)).ask()
        if f.kind == "password":
            return questionary.password(label, style=style,
                                        validate=f.validate or (lambda _: True)).ask()
        if f.kind == "confirm":
            return questionary.confirm(label, default=bool(f.default),
                                       style=style).ask()
        if f.kind == "select":
            return questionary.select(label, choices=f.choices or [],
                                      default=f.default, style=style).ask()
        if f.kind == "multi":
            return questionary.checkbox(label, choices=f.choices or [],
                                        style=style).ask()
        if f.kind == "number":
            def v(x):
                try:
                    n = int(x)
                except ValueError:
                    return "Enter a number"
                if f.min is not None and n < f.min: return f">= {f.min}"
                if f.max is not None and n > f.max: return f"<= {f.max}"
                return True
            raw = questionary.text(label, default=str(f.default),
                                   style=style, validate=v).ask()
            return int(raw) if raw is not None else None
        if f.kind == "path":
            return questionary.path(label, default=str(f.default or ""),
                                    style=style).ask()
        return None


# alias
picopy = App


__all__ = [
    "App", "picopy", "Menu", "Form", "Terminal", "Spinner", "Progress",
    "paint", "markup", "strip_ansi", "visible_len", "THEMES",
]